#include "sdl2.h"


/**
* @brief Elle renverra une enum Event pour la gestion de clavier avec fgetc
* @param void
*/

Event event();




/**
* @brief Elle renverra une enum Event
* @param void
*/
Event event_sdl2();